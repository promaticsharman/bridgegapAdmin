export const environment = {
  production: true,
  // endPoint: "https://developers.promaticstechnologies.com:3003/",
  // endPoint_localhost: "http://localhost:3002/",
  endPoint:"https://production.promaticstechnologies.com:3009/"
};
