import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-student-details',
  templateUrl: './view-student-details.component.html',
  styleUrls: ['./view-student-details.component.css']
})
export class ViewStudentDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
