import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacher-management',
  templateUrl: './teacher-management.component.html',
  styleUrls: ['./teacher-management.component.css']
})
export class TeacherManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
