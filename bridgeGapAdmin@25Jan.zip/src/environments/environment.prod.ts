export const environment = {
  production: true,
  // endPoint: "https://developers.promaticstechnologies.com:3003/",
  // endPoint_localhost: "http://localhost:3002/",
  endPoint:"https://production.promaticstechnologies.com:3009/",
  home_image:"https://production.promaticstechnologies.com/bridgegap_apis/public/home_banner_images/",

  testimonials_img:"https://production.promaticstechnologies.com/bridgegap_apis/public/",
  banner_img:"https://production.promaticstechnologies.com/bridgegap_apis/public/",
  category_images:"https://production.promaticstechnologies.com/bridgegap_apis/public/",
  cateImg:"https://production.promaticstechnologies.com/bridgegap_apis/public/category_images/",
  subCatImg:"https://production.promaticstechnologies.com/bridgegap_apis/public/sub_category_images/",
  subCategory_images:"https://production.promaticstechnologies.com/bridgegap_apis/public/",
  engaging_image:"https://production.promaticstechnologies.com/bridgegap_apis/public/engaging_and_efficient_images/",
  engag_img:"https://production.promaticstechnologies.com/bridgegap_apis/public/",
  how_it_works_img:"https://production.promaticstechnologies.com/bridgegap_apis/public/how_its_works_images/",
  how_it_img:"https://production.promaticstechnologies.com/bridgegap_apis/public/",
  application_image:"https://production.promaticstechnologies.com/bridgegap_apis/public/teacher_videos/"

};
