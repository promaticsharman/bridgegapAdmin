import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newsletter-management',
  templateUrl: './newsletter-management.component.html',
  styleUrls: ['./newsletter-management.component.css']
})
export class NewsletterManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
